<p>ขอบคุณที่สนับสนุนกันนะครับ สามารถสนับสนุนได้ที่นี่</p> 
<img src="https://img2.pic.in.th/pic/-----Thank-You-Postcard-1.png"/>
<p>ขั้นการดาวโหลด หรือ โคลนโปรเจ็คไปแล้ว</p> 
<p>Run : git clone https://github.com/Weeraphong-Surapo/vuejs_laravel_api_auth.git</p> 
<p>หรือกดาวโหลด</p> <p>Laravel มีขั้นตอนดังนี้</p> 
<p>เข้า terminal ของโปรเจ็ค laravel แล้ว</p> 
<p>1.Run : composer install</p> 
<p>2.Run : cp .env.example .env</p> 
<p>3.Run : php artisan key:generate</p> 
<p>4.Run : php artisan migrate </p> 
<p>5.Run : php artisan serve</p> 
<p>6.Go to link localhost:8000 หรือ ตามที่ terminal แจ้ง</p> 
<p>Vuejs มีขั้นตอนดังนี้</p> 
<p>เข้า terminal ของโปรเจ็ค laravel แล้ว</p> 
<p>1.Run : npm install</p> 
<p>2.Run : npm run dev</p> 
<p>3.Go to link localhost:5173 หรือ ตามที่ terminal แจ้ง</p> 
<p>ดูโปรเจ็คอื่นๆ</p> 
<a href="https://innovation-develop.com">คลิกที่นี่</a>
